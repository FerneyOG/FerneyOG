package co.com.choucair.certification.proyectobase.model;

public class AcademyChoucairData {

    private String strUser;
    private String strPassword;
    private String strCourse;


    public void setStrUser(String strUser) {
        this.strUser = strUser;
    }

    public void setStrPassword(String strPassword) {
        this.strPassword = strPassword;
    }

    public void setStrCourse(String strCourse) {
        this.strCourse = strCourse;
    }

    public String getStrUser() {
        return strUser;
    }

    public String getStrPassword() {
        return strPassword;
    }

    public String getStrCourse() {
        return strCourse;
    }

}
